import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://wmyaalemhmcjtutlwfwr.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndteWFhbGVtaG1janR1dGx3ZndyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2MTYzMzcsImV4cCI6MjA4NTE5MjMzN30.cCJRE8xLKcgEiu-5qYG7vmRbowkConFYRw8TT4lQ6Ks'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface Asset {
  id: string
  name: string
  model_sid: string
  thumbnail_url?: string
  description?: string
  location?: string
  status?: string
  manufacturer?: string
  serial_number?: string
  created_at: string
  updated_at: string
}

export interface Mark {
  id: string
  asset_id: string
  label: string
  description?: string
  position_x: number
  position_y: number
  position_z: number
  normal_x?: number
  normal_y?: number
  normal_z?: number
  camera_position?: any
  camera_rotation?: any
  mattertag_id?: string
  created_at: string
}

export interface CalendarEvent {
  id: string
  title: string
  description?: string
  event_type: string
  event_date: string
  event_time?: string
  location?: string
  linked_mark_id?: string
  linked_asset_id?: string
  status: string
  created_at: string
}

export interface Media {
  id: string
  title: string
  description?: string
  file_url: string
  file_type: string
  category?: string
  thumbnail_url?: string
  created_at: string
}