import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Vision from './pages/Vision'

// Other placeholders remain the same
const Assets = () => <div className="text-white">Assets Page Coming Soon</div>
const Media = () => <div className="text-white">Media Library Coming Soon</div>
const Marks = () => <div className="text-white">Marks Editor Coming Soon</div>
const Calendar = () => <div className="text-white">Calendar Coming Soon</div>
const Users = () => <div className="text-white">Users Coming Soon</div>
const Settings = () => <div className="text-white">Settings Coming Soon</div>

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="vision" element={<Vision />} />
          <Route path="assets" element={<Assets />} />
          <Route path="media" element={<Media />} />
          <Route path="marks" element={<Marks />} />
          <Route path="calendar" element={<Calendar />} />
          <Route path="users" element={<Users />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App