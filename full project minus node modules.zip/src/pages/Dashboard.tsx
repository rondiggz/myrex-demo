import { useEffect, useState } from 'react'
import { supabase, type Asset, type CalendarEvent } from '../lib/supabase'
import { ChevronLeft, ChevronRight } from 'lucide-react'

export default function Dashboard() {
  const [assets, setAssets] = useState<Asset[]>([])
  const [events, setEvents] = useState<CalendarEvent[]>([])
  const [loading, setLoading] = useState(true)

  // Animation styles for production chart
  const chartAnimationStyle = `
    @keyframes slideUp {
      from {
        transform: scaleY(0);
        opacity: 0;
      }
      to {
        transform: scaleY(1);
        opacity: 1;
      }
    }
  `

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const { data: assetsData } = await supabase
        .from('assets')
        .select('*')
        .order('created_at', { ascending: false })

      const { data: eventsData } = await supabase
        .from('calendar_events')
        .select('*')
        .gte('event_date', new Date().toISOString().split('T')[0])
        .order('event_date', { ascending: true })
        .limit(4)

      setAssets(assetsData || [])
      setEvents(eventsData || [])
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getEventTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      maintenance: 'bg-orange-500 text-white',
      inspection: 'bg-yellow-500 text-black',
      training: 'bg-purple-500 text-white',
      meeting: 'bg-blue-500 text-white',
    }
    return colors[type] || 'bg-gray-500 text-white'
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-gray-400">Loading...</div>
      </div>
    )
  }

  return (
    <>
      <style>{chartAnimationStyle}</style>
      <div className="flex gap-3 h-full overflow-hidden">
      {/* Main Content */}
      <div className="flex-1 space-y-3 overflow-auto pr-2">
        {/* Hero Carousel */}
        <div className="relative bg-gradient-to-br from-[#2d3561] via-[#1e2139] to-[#2d3561] rounded-xl overflow-hidden border border-blue-500/20">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDMpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-40"></div>

          <button className="absolute left-4 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-sm flex items-center justify-center text-white transition-all duration-200 z-10 hover:scale-110">
            <ChevronLeft size={18} />
          </button>
          <button className="absolute right-4 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-sm flex items-center justify-center text-white transition-all duration-200 z-10 hover:scale-110">
            <ChevronRight size={18} />
          </button>

          <div className="relative p-10">
            <div className="flex items-start gap-8">
              <div className="flex-1">
                <div className="text-blue-400 text-[11px] font-bold tracking-[0.15em] mb-2.5 uppercase">Powered by Matterport</div>
                <h1 className="text-4xl font-bold text-white mb-3 leading-tight tracking-tight">Digital Twin Platform</h1>
                <p className="text-gray-400 text-sm mb-5 max-w-xl leading-relaxed">
                  Navigate your facility in immersive 3D. Create marks, track issues,
                  and collaborate in real-time.
                </p>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all shadow-lg hover:shadow-blue-500/50 hover:scale-105">
                  Explore Twin
                </button>
              </div>
              <div className="text-[160px] leading-none opacity-10 select-none">🏭</div>
            </div>
          </div>

          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-lg shadow-blue-500/50"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-white/30 hover:bg-white/50 transition-colors cursor-pointer"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-white/30 hover:bg-white/50 transition-colors cursor-pointer"></div>
          </div>
        </div>

        {/* Quick Access Cards */}
        <div className="grid grid-cols-4 gap-2.5">
          {[
            { icon: '📦', title: 'Assets', subtitle: '3D Assets & Equipment', color: 'blue' },
            { icon: '📚', title: 'Media Library', subtitle: 'Videos, Docs, Design Files, Photos', color: 'green' },
            { icon: '🔧', title: 'Maintenance Hub', subtitle: 'Maintenance & Operations', color: 'purple' },
            { icon: '🎓', title: 'Academy | Compliance', subtitle: 'Training & Compliance', color: 'yellow' },
          ].map((item, i) => (
            <div key={i} className="group bg-[#1a1a1a] rounded-lg p-4 border border-[#2a2a2a] hover:border-blue-500/50 transition-all duration-200 cursor-pointer hover:scale-105">
              <div className="text-2xl mb-2">{item.icon}</div>
              <h3 className="text-white font-semibold mb-0.5 text-sm group-hover:text-blue-400 transition-colors">{item.title}</h3>
              <p className="text-gray-500 text-[11px] leading-snug">{item.subtitle}</p>
            </div>
          ))}
        </div>

        {/* IoT at a Glance */}
        <div className="bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] overflow-hidden">
          <div className="px-5 py-3.5 border-b border-[#2a2a2a] flex items-center justify-between">
            <div>
              <h2 className="text-white font-bold text-sm">IoT at a Glance</h2>
              <p className="text-gray-500 text-[11px] mt-0.5">Real-time equipment status</p>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-green-400 text-xs font-semibold">Live</span>
            </div>
          </div>

          <div className="grid grid-cols-4 divide-x divide-[#2a2a2a]">
            {[
              { label: 'OEE', value: '87.3%', change: '+2.1% from yesterday', changeColor: 'text-green-500' },
              { label: 'Active Machines', value: '3/4', change: '1 in maintenance', changeColor: 'text-yellow-500' },
              { label: "Today's Output", value: '12,480', change: 'parts produced', changeColor: 'text-gray-500' },
              { label: 'System Status', value: 'Operational', change: 'All systems normal', changeColor: 'text-gray-500', valueColor: 'text-green-500' },
            ].map((stat, i) => (
              <div key={i} className="p-5">
                <div className="text-gray-500 text-[11px] mb-1.5 font-medium uppercase tracking-wide">{stat.label}</div>
                <div className={`text-2xl font-bold mb-1 ${stat.valueColor || 'text-white'}`}>{stat.value}</div>
                <div className={`text-[11px] ${stat.changeColor}`}>{stat.change}</div>
              </div>
            ))}
          </div>

          {/* Production Chart */}
          <div className="p-5 border-t border-[#2a2a2a]">
            <div className="flex items-center justify-between mb-3.5">
              <h3 className="text-white font-semibold text-sm">Production Output (24h)</h3>
              <div className="flex gap-3 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-500"></div>
                  <span className="text-gray-500">Output</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500"></div>
                  <span className="text-gray-500">Target</span>
                </div>
              </div>
            </div>
            <div className="h-28 bg-[#0a0a0a] rounded-lg flex items-end justify-between px-2.5 pb-2.5 gap-0.5">
              {Array.from({ length: 24 }).map((_, i) => {
                const height = 30 + Math.random() * 70
                return (
                  <div
                    key={i}
                    className="flex-1 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t hover:from-blue-500 hover:to-blue-300 transition-all duration-200 cursor-pointer hover:scale-105 hover:shadow-lg hover:shadow-blue-500/50"
                    style={{
                      height: `${height}%`,
                      animation: `slideUp 0.6s ease-out ${i * 0.02}s backwards`
                    }}
                  ></div>
                )
              })}
            </div>
            <div className="flex justify-between text-[11px] text-gray-600 mt-2 px-2.5">
              <span>12AM</span>
              <span>6AM</span>
              <span>12PM</span>
              <span>6PM</span>
              <span>Now</span>
            </div>
          </div>
        </div>

        {/* Ask Vision AI */}
        <div className="bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] p-5">
          <div className="flex items-start gap-3 mb-3.5">
            <div className="text-2xl">🤖</div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-0.5">
                <h3 className="text-white font-bold text-sm">Ask Vision AI</h3>
                <div className="px-2 py-0.5 bg-blue-500 text-white text-[10px] font-bold rounded uppercase tracking-wide">Live</div>
              </div>
              <p className="text-gray-500 text-xs">Your equipment expert</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {['How do I calibrate G05?', 'Show maintenance schedule', 'Find training videos'].map((q, i) => (
              <button key={i} className="text-left px-3 py-2.5 bg-[#0a0a0a] hover:bg-[#2a2a2a] rounded-lg text-xs text-gray-400 transition-all duration-200 border border-transparent hover:border-blue-500/30 hover:text-gray-300">
                {q}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Right Sidebar */}
      <div className="w-80 space-y-3 overflow-auto">
        {/* Events */}
        <div className="bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] overflow-hidden">
          <div className="px-4 py-3 border-b border-[#2a2a2a] flex items-center justify-between">
            <h2 className="text-white font-bold text-sm flex items-center gap-1.5">
              <span className="text-base">📅</span> Events
            </h2>
            <button className="text-blue-400 text-xs hover:text-blue-300 font-semibold transition-colors">Today</button>
          </div>
          <div className="p-3.5 space-y-3.5">
            {[
              { date: 2, month: 'Feb', title: 'CNC Machine Maintenance', time: '9:00 AM', location: 'Production Floor', type: 'maintenance' },
              { date: 3, month: 'Feb', title: 'Safety Inspection', time: '2:00 PM', location: 'Assembly Line A', type: 'inspection' },
              { date: 4, month: 'Feb', title: 'Team Standup', time: '10:00 AM', location: 'Conference Room', type: 'meeting' },
              { date: 5, month: 'Feb', title: 'Equipment Training', time: '1:00 PM', location: 'Training Center', type: 'training' },
            ].map((event, i) => (
              <div key={i} className="flex gap-3">
                <div className="flex flex-col items-center shrink-0">
                  <div className="w-12 h-12 rounded-full bg-[#2a2a2a] flex flex-col items-center justify-center">
                    <div className="text-lg font-bold text-white leading-none">{event.date}</div>
                    <div className="text-[10px] text-gray-500 uppercase leading-none mt-0.5">{event.month}</div>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-medium text-sm mb-1.5 truncate">{event.title}</h3>
                  <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-2">
                    <span className="flex items-center gap-1">
                      <span className="text-gray-600">🕐</span> {event.time}
                    </span>
                    <span className="text-gray-700">•</span>
                    <span className="truncate flex items-center gap-1">
                      <span className="text-gray-600">📍</span> {event.location}
                    </span>
                  </div>
                  <span className={`inline-block px-2.5 py-1 rounded text-xs font-semibold ${getEventTypeColor(event.type)}`}>
                    {event.type.toUpperCase()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] overflow-hidden">
          <div className="px-4 py-3 border-b border-[#2a2a2a]">
            <h2 className="text-white font-bold text-sm flex items-center gap-1.5">
              <span className="text-base">🔔</span> Notifications
            </h2>
          </div>
          <div className="p-4">
            <div className="text-center py-6 text-gray-500 text-xs">
              No new notifications
            </div>
          </div>
        </div>

        {/* Support */}
        <div className="bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] overflow-hidden">
          <div className="px-4 py-3 border-b border-[#2a2a2a]">
            <h2 className="text-white font-bold text-sm flex items-center gap-1.5">
              <span className="text-base">💬</span> Support
            </h2>
          </div>
          <div className="p-3.5">
            <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 px-4 rounded-lg text-sm font-semibold transition-all duration-200 shadow-lg hover:shadow-blue-500/30 hover:scale-105">
              Contact Support
            </button>
          </div>
        </div>
      </div>
    </div>
    </>
  )
}
