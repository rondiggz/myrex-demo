import { useEffect, useRef, useState } from 'react'
import { supabase } from '../lib/supabase'
import { Save, X, Eye } from 'lucide-react'

declare global {
  interface Window {
    MP_SDK: {
      connect: (
        showcase: Window,
        applicationKey?: string,
        sdkVersion?: string
      ) => Promise<any>
    }
  }
}

interface Mark {
  id: string
  label: string
  description: string
  position: { x: number; y: number; z: number }
  normal: { x: number; y: number; z: number }
  mattertag_id?: string
}

export default function Vision() {
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const [sdk, setSdk] = useState<any>(null)
  const [isReady, setIsReady] = useState(false)
  const [isAddMode, setIsAddMode] = useState(false)
  const [marks, setMarks] = useState<Mark[]>([])
  const [currentIntersection, setCurrentIntersection] = useState<any>(null)
  const [selectedAsset, setSelectedAsset] = useState<string>('BGfbBBXhrZf')
  const [showSaveModal, setShowSaveModal] = useState(false)
  const [newMark, setNewMark] = useState<any>(null)

  // Connect to Bundle SDK
  useEffect(() => {
    const iframe = iframeRef.current
    if (!iframe) return

    const onLoad = async () => {
      try {
        const showcaseWindow = iframe.contentWindow
        if (!showcaseWindow) return

        console.log('[VISION] Connecting to Bundle SDK...')
        
        const mpSdk = await showcaseWindow.MP_SDK.connect(
          showcaseWindow,
          '76zueyye7kqqag4uxtw7kem5d',
          ''
        )

        setSdk(mpSdk)

        await mpSdk.App.state.waitUntil(
          (state: any) => state.phase === mpSdk.App.Phase.PLAYING
        )

        console.log('[VISION] ✅ Ready!')
        setIsReady(true)

        // Load existing marks from database
        loadMarks()

      } catch (error) {
        console.error('[VISION] ❌ Connection failed:', error)
      }
    }

    iframe.addEventListener('load', onLoad)
    return () => iframe.removeEventListener('load', onLoad)
  }, [])

  // Load marks from database
  const loadMarks = async () => {
    try {
      const { data } = await supabase
        .from('marks')
        .select('*')
        .order('created_at', { ascending: false })

      if (data) {
        // Convert database marks to display marks
        const displayMarks = data.map(m => ({
          id: m.id,
          label: m.label,
          description: m.description || '',
          position: { x: m.position_x, y: m.position_y, z: m.position_z },
          normal: { x: m.normal_x || 0, y: m.normal_y || 0, z: m.normal_z || 0 },
          mattertag_id: m.mattertag_id
        }))
        setMarks(displayMarks)
      }
    } catch (error) {
      console.error('Error loading marks:', error)
    }
  }

  // Track intersection
  useEffect(() => {
    if (!sdk || !isReady) return

    const subscription = sdk.Pointer.intersection.subscribe((intersection: any) => {
      if (intersection && intersection.position) {
        setCurrentIntersection({
          position: intersection.position,
          normal: intersection.normal,
        })
      } else {
        setCurrentIntersection(null)
      }
    })

    return () => subscription.cancel()
  }, [sdk, isReady])

  // Handle clicks
  useEffect(() => {
    if (!isAddMode || !currentIntersection || !sdk) return

    const handleWindowBlur = async () => {
      if (currentIntersection) {
        const { position, normal } = currentIntersection
        
        try {
          const tagIds = await sdk.Mattertag.add({
            label: `Mark ${marks.length + 1}`,
            description: 'Click to edit',
            anchorPosition: position,
            stemVector: {
              x: normal.x * 0.3,
              y: normal.y * 0.3,
              z: normal.z * 0.3,
            },
            color: { r: 0.2, g: 0.8, b: 0.3 },
          })

          const cameraPose = await sdk.Camera.getPose()

          setNewMark({
            mattertag_id: tagIds[0],
            position,
            normal,
            camera_position: cameraPose.position,
            camera_rotation: cameraPose.rotation,
          })

          setShowSaveModal(true)
          setIsAddMode(false)
        } catch (error) {
          console.error('[VISION] Failed to create mark:', error)
        }
      }
    }

    window.addEventListener('blur', handleWindowBlur)
    return () => window.removeEventListener('blur', handleWindowBlur)
  }, [isAddMode, currentIntersection, sdk, marks.length])

  const handleSaveMark = async () => {
    if (!newMark) return

    const label = (document.getElementById('mark-label') as HTMLInputElement)?.value || 'Untitled Mark'
    const description = (document.getElementById('mark-description') as HTMLTextAreaElement)?.value || ''

    try {
      const { data: asset } = await supabase
        .from('assets')
        .select('id')
        .eq('model_sid', selectedAsset)
        .single()

      if (!asset) {
        alert('Asset not found!')
        return
      }

      const { data, error } = await supabase
        .from('marks')
        .insert({
          asset_id: asset.id,
          label,
          description,
          position_x: newMark.position.x,
          position_y: newMark.position.y,
          position_z: newMark.position.z,
          normal_x: newMark.normal.x,
          normal_y: newMark.normal.y,
          normal_z: newMark.normal.z,
          camera_position: newMark.camera_position,
          camera_rotation: newMark.camera_rotation,
          mattertag_id: newMark.mattertag_id,
        })
        .select()
        .single()

      if (error) throw error

      console.log('[VISION] ✅ Mark saved to database!')
      
      setMarks(prev => [...prev, {
        id: data.id,
        label,
        description,
        position: newMark.position,
        normal: newMark.normal,
        mattertag_id: newMark.mattertag_id,
      }])

      setShowSaveModal(false)
      setNewMark(null)
    } catch (error) {
      console.error('Error saving mark:', error)
      alert('Failed to save mark')
    }
  }

  return (
    <div className="relative h-full flex">
      {/* 3D Viewer */}
      <div className="flex-1 relative">
        <iframe
          ref={iframeRef}
          src={`/bundle/showcase.html?m=${selectedAsset}&play=1&qs=1&applicationKey=76zueyye7kqqag4uxtw7kem5d`}
          className="w-full h-full border-none"
          allow="xr-spatial-tracking; camera; microphone"
          allowFullScreen
        />

        {/* Controls Overlay */}
        {isReady && (
          <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-sm rounded-lg p-4 border border-white/10 min-w-[280px]">
            <div className="flex items-center gap-3 mb-4">
              <Eye className="text-blue-400" size={24} />
              <div>
                <h3 className="text-white font-bold">VISION</h3>
                <p className="text-gray-400 text-xs">3D Asset Viewer</p>
              </div>
            </div>

            <button
              onClick={() => setIsAddMode(!isAddMode)}
              className={`w-full py-3 rounded-lg font-medium transition-colors mb-3 ${
                isAddMode
                  ? 'bg-red-600 hover:bg-red-700 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {isAddMode ? '❌ CANCEL' : '➕ ADD MARK'}
            </button>

            {isAddMode && (
              <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3 mb-3">
                <p className="text-blue-300 text-sm">
                  💡 Click anywhere on the 3D model to place a mark
                </p>
                <p className="text-blue-400/60 text-xs mt-2">
                  {currentIntersection ? '✅ Surface detected' : '⏳ Hover over surface...'}
                </p>
              </div>
            )}

            <div className="space-y-2">
              <div className="text-gray-400 text-xs font-medium">Marks placed: {marks.length}</div>
              <div className="max-h-40 overflow-y-auto space-y-1">
                {marks.map(mark => (
                  <div
                    key={mark.id}
                    className="bg-white/5 hover:bg-white/10 rounded px-3 py-2 text-sm text-white cursor-pointer transition-colors"
                  >
                    {mark.label}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {!isReady && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50">
            <div className="text-white text-lg">Loading 3D model...</div>
          </div>
        )}
      </div>

      {/* Save Mark Modal */}
      {showSaveModal && (
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">Save Mark</h3>
              <button
                onClick={() => setShowSaveModal(false)}
                className="text-gray-400 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-gray-400 text-sm block mb-2">Label</label>
                <input
                  id="mark-label"
                  type="text"
                  defaultValue={`Mark ${marks.length + 1}`}
                  className="w-full bg-[#0a0a0a] text-white px-4 py-2 rounded-lg border border-[#2a2a2a] focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-gray-400 text-sm block mb-2">Description</label>
                <textarea
                  id="mark-description"
                  rows={3}
                  placeholder="Add description..."
                  className="w-full bg-[#0a0a0a] text-white px-4 py-2 rounded-lg border border-[#2a2a2a] focus:border-blue-500 focus:outline-none resize-none"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowSaveModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveMark}
                  className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Save size={16} />
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}